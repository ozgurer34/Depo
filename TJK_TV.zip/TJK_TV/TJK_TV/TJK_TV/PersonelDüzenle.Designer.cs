﻿namespace TJK_TV
{
    partial class PersonelDüzenle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.Lblid = new System.Windows.Forms.Label();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.PerTel = new System.Windows.Forms.MaskedTextBox();
            this.PerTc = new System.Windows.Forms.MaskedTextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.PerSoyad = new System.Windows.Forms.TextBox();
            this.PerUnvan = new System.Windows.Forms.ComboBox();
            this.PerDogum = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.Peril = new System.Windows.Forms.TextBox();
            this.PerAd = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.Lbliki = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.Lblbir = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.BtnKaydet = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(441, 286);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(71, 30);
            this.radioButton2.TabIndex = 42;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "KADIN";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // Lblid
            // 
            this.Lblid.AutoSize = true;
            this.Lblid.Location = new System.Drawing.Point(452, -2);
            this.Lblid.Name = "Lblid";
            this.Lblid.Size = new System.Drawing.Size(80, 26);
            this.Lblid.TabIndex = 44;
            this.Lblid.Text = "Personel Id";
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(362, 286);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(73, 30);
            this.radioButton1.TabIndex = 41;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "ERKEK";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // PerTel
            // 
            this.PerTel.Location = new System.Drawing.Point(362, 242);
            this.PerTel.Mask = "(999) 000-0000";
            this.PerTel.Name = "PerTel";
            this.PerTel.Size = new System.Drawing.Size(150, 27);
            this.PerTel.TabIndex = 40;
            // 
            // PerTc
            // 
            this.PerTc.Location = new System.Drawing.Point(362, 27);
            this.PerTc.Mask = "00000000000";
            this.PerTc.Name = "PerTc";
            this.PerTc.Size = new System.Drawing.Size(150, 27);
            this.PerTc.TabIndex = 35;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Encode Sans Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.Location = new System.Drawing.Point(290, 112);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 26);
            this.label2.TabIndex = 52;
            this.label2.Text = "Soyad :";
            // 
            // PerSoyad
            // 
            this.PerSoyad.Location = new System.Drawing.Point(362, 112);
            this.PerSoyad.Name = "PerSoyad";
            this.PerSoyad.Size = new System.Drawing.Size(150, 27);
            this.PerSoyad.TabIndex = 37;
            // 
            // PerUnvan
            // 
            this.PerUnvan.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.PerUnvan.FormattingEnabled = true;
            this.PerUnvan.Location = new System.Drawing.Point(362, 154);
            this.PerUnvan.Name = "PerUnvan";
            this.PerUnvan.Size = new System.Drawing.Size(150, 34);
            this.PerUnvan.TabIndex = 38;
            // 
            // PerDogum
            // 
            this.PerDogum.Location = new System.Drawing.Point(362, 332);
            this.PerDogum.Name = "PerDogum";
            this.PerDogum.Size = new System.Drawing.Size(150, 27);
            this.PerDogum.TabIndex = 43;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Encode Sans Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.Location = new System.Drawing.Point(280, 286);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 26);
            this.label3.TabIndex = 48;
            this.label3.Text = "Cinsiyet :";
            // 
            // Peril
            // 
            this.Peril.Location = new System.Drawing.Point(362, 203);
            this.Peril.Name = "Peril";
            this.Peril.Size = new System.Drawing.Size(150, 27);
            this.Peril.TabIndex = 39;
            // 
            // PerAd
            // 
            this.PerAd.Location = new System.Drawing.Point(362, 69);
            this.PerAd.Name = "PerAd";
            this.PerAd.Size = new System.Drawing.Size(150, 27);
            this.PerAd.TabIndex = 36;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Encode Sans Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label6.Location = new System.Drawing.Point(255, 332);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(89, 26);
            this.label6.TabIndex = 51;
            this.label6.Text = "Doğum Yeri :";
            // 
            // Lbliki
            // 
            this.Lbliki.AutoSize = true;
            this.Lbliki.Font = new System.Drawing.Font("Encode Sans Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.Lbliki.Location = new System.Drawing.Point(287, 154);
            this.Lbliki.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Lbliki.Name = "Lbliki";
            this.Lbliki.Size = new System.Drawing.Size(58, 26);
            this.Lbliki.TabIndex = 46;
            this.Lbliki.Text = "Unvan :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Encode Sans Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label5.Location = new System.Drawing.Point(261, 246);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(84, 26);
            this.label5.TabIndex = 50;
            this.label5.Text = "Telefon No :";
            // 
            // Lblbir
            // 
            this.Lblbir.AutoSize = true;
            this.Lblbir.Font = new System.Drawing.Font("Encode Sans Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.Lblbir.Location = new System.Drawing.Point(309, 72);
            this.Lblbir.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Lblbir.Name = "Lblbir";
            this.Lblbir.Size = new System.Drawing.Size(35, 26);
            this.Lblbir.TabIndex = 45;
            this.Lblbir.Text = "Ad :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Encode Sans Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.Location = new System.Drawing.Point(291, 27);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(54, 26);
            this.label4.TabIndex = 49;
            this.label4.Text = "TC No :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Encode Sans Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(320, 203);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(25, 26);
            this.label1.TabIndex = 47;
            this.label1.Text = "İl :";
            // 
            // BtnKaydet
            // 
            this.BtnKaydet.BackColor = System.Drawing.Color.MediumAquamarine;
            this.BtnKaydet.Font = new System.Drawing.Font("Encode Sans Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.BtnKaydet.Location = new System.Drawing.Point(184, 435);
            this.BtnKaydet.Name = "BtnKaydet";
            this.BtnKaydet.Size = new System.Drawing.Size(251, 59);
            this.BtnKaydet.TabIndex = 53;
            this.BtnKaydet.Text = "KAYDET";
            this.BtnKaydet.UseVisualStyleBackColor = false;
            this.BtnKaydet.Click += new System.EventHandler(this.BtnKaydet_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(30, 27);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(210, 285);
            this.pictureBox1.TabIndex = 54;
            this.pictureBox1.TabStop = false;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(78, 332);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(108, 35);
            this.button1.TabIndex = 55;
            this.button1.Text = "Resim Seç";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // PersonelDüzenle
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 26F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(549, 523);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.BtnKaydet);
            this.Controls.Add(this.radioButton2);
            this.Controls.Add(this.Lblid);
            this.Controls.Add(this.radioButton1);
            this.Controls.Add(this.PerTel);
            this.Controls.Add(this.PerTc);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.PerSoyad);
            this.Controls.Add(this.PerUnvan);
            this.Controls.Add(this.PerDogum);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.Peril);
            this.Controls.Add(this.PerAd);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.Lbliki);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.Lblbir);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Encode Sans Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.Name = "PersonelDüzenle";
            this.Text = "PersonelDüzenle";
            this.Load += new System.EventHandler(this.PersonelDüzenle_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.Label Lblid;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.MaskedTextBox PerTel;
        private System.Windows.Forms.MaskedTextBox PerTc;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox PerSoyad;
        private System.Windows.Forms.ComboBox PerUnvan;
        private System.Windows.Forms.TextBox PerDogum;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox Peril;
        private System.Windows.Forms.TextBox PerAd;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label Lbliki;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label Lblbir;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button BtnKaydet;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button button1;
    }
}