﻿namespace TJK_TV {
    
    
    public partial class DataSet1 {
    }
}

namespace TJK_TV.DataSet1TableAdapters {
    
    
    public partial class PersonelTableAdapter {
    }
}
