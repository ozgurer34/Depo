﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TJK_TV
{
    public partial class Giris : Form
    {
        public Giris()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            DateTime tarih;
            tarih = dateTimePicker1.Value;
            LblGun.Text = tarih.ToString("dd");
            lblAyyıl.Text = tarih.ToString("MMMM yyyy");
            LblGunad.Text = tarih.ToString("dddd");
//            LblSaniye.Text = tarih.ToString("ff");
            LblSaat.Text = DateTime.Now.Hour.ToString();
            LblDakkika.Text = DateTime.Now.Minute.ToString();
            
        }
        sqlbaglantisi bgl = new sqlbaglantisi();
        private void BtnGiris_Click(object sender, EventArgs e)
        {
            SqlCommand komut = new SqlCommand("SELECT * FROM Giris WHERE UyeAd=@p1 and UyeSifre=@p2", bgl.baglanti());
/*            SqlDataReader dr = komut.ExecuteReader();
            if (dr.Read())
            {
                Secenekler frm = new Secenekler();
                frm.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Kullanıcı adınızı veye Şifrenizi yanlış girdiniz...");
            }
            bgl.baglanti().Close();
 */ 
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        string deneme;
        int saniye;
        private void timer1_Tick(object sender, EventArgs e)
        {


            deneme = LblSaniye.Text = DateTime.Now.Second.ToString();
 //           LblSaniye.Text = saniye.ToString();
            button1.FlatStyle = FlatStyle.Flat;
            button1.FlatAppearance.BorderSize = 0;
            button1.Width = 16 * Convert.ToInt16(deneme);
  //          panel1.Size = new System.Drawing.Size(panel1.Size.Width + Convert.ToInt16(saniye) , panel1.Size.Height);
        }
    }
}
