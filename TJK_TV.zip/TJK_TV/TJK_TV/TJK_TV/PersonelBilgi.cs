﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TJK_TV
{
   
    public partial class PersonelBilgi : Form
    {
        DataSet1TableAdapters.DataTable1TableAdapter ds = new DataSet1TableAdapters.DataTable1TableAdapter();
        DataSet1TableAdapters.UnvanTableAdapter un = new DataSet1TableAdapters.UnvanTableAdapter();
        sqlbaglantisi bgl = new sqlbaglantisi();
        PersonelDüzenle pd = new PersonelDüzenle();
       

        public PersonelBilgi()
        {
            InitializeComponent();
        }
        
        private void PersonelBilgi_Load(object sender, EventArgs e)
        
        {
            this.ActiveControl = PerTc;
           
            dataGridView1.DataSource = ds.PersonelListele();

            PerTc.Text = "";
            PerAd.Text = "";
            PerSoyad.Text = "";
            Peril.Text = "";
            PerTel.Text = "";
            PerDogum.Text = "";
            pictureBox1.ImageLocation = "";
            PerUnvan.Text = "";

            bgl.baglanti().Close();
            SqlCommand komut = new SqlCommand("SELECT * FROM Unvan", bgl.baglanti());
            SqlDataAdapter da = new SqlDataAdapter(komut);
            DataTable dt = new DataTable();
            da.Fill(dt);
            PerUnvan.DisplayMember = "Unvanad";
            PerUnvan.ValueMember = "Unvanid";
            PerUnvan.DataSource = dt;
            bgl.baglanti().Close();
        }

        
        
        private void BtnKaydet_Click(object sender, EventArgs e)
        {
            string c = "";
            if(radioButton1.Checked==true)
            {
                c="ERKEK";
            }
            if(radioButton2.Checked==true)
            {
                c = "KADIN";
            }
            ds.PersonelEkle(PerTc.Text, PerAd.Text, PerSoyad.Text, byte.Parse(PerUnvan.SelectedValue.ToString()), Peril.Text, PerTel.Text,c, PerDogum.Text, LblResim.Text);   
            MessageBox.Show("Personel Eklendi");
        }

        
        private void BtnListele_Click_1(object sender, EventArgs e)
        {
            
            dataGridView1.DataSource = ds.PersonelListele();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            openFileDialog1.ShowDialog();
            pictureBox1.ImageLocation = openFileDialog1.FileName;
            LblResim.Text = openFileDialog1.FileName;
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            
       //    Lblid.Text = dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
           LblTc.Text = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
           LblAd.Text = dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();
           LblSoyad.Text = dataGridView1.Rows[e.RowIndex].Cells[3].Value.ToString();
           LblUnvan.Text = dataGridView1.Rows[e.RowIndex].Cells[9].Value.ToString();
           Lblil.Text = dataGridView1.Rows[e.RowIndex].Cells[4].Value.ToString();
           LblTel.Text = dataGridView1.Rows[e.RowIndex].Cells[5].Value.ToString();
           LblCins.Text = dataGridView1.Rows[e.RowIndex].Cells[6].Value.ToString();
           LblDogum.Text = dataGridView1.Rows[e.RowIndex].Cells[7].Value.ToString();
           pictureBox1.ImageLocation = dataGridView1.Rows[e.RowIndex].Cells[8].Value.ToString();
           pd.numara = dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
        }

        private void BtnSil_Click(object sender, EventArgs e)
        {
           // ds.PersonelSil(int.Parse(TextID.Text));  
        }

        private void button2_Click(object sender, EventArgs e)
        {
            pd.Show();
            this.Hide();
        }

    }
}
