﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TJK_TV
{
    public partial class PersonelDüzenle : Form
    {
        public PersonelDüzenle()
        {
            InitializeComponent();
        }

        DataSet1TableAdapters.PersonelTableAdapter ds = new DataSet1TableAdapters.PersonelTableAdapter();
        DataSet1TableAdapters.UnvanTableAdapter un = new DataSet1TableAdapters.UnvanTableAdapter();

        sqlbaglantisi bgl = new sqlbaglantisi();
        public string numara;

        private void PersonelDüzenle_Load(object sender, EventArgs e)
        {
            this.Text = numara.ToString();

        }

        private void BtnKaydet_Click(object sender, EventArgs e)
        {

        }
    }
}
