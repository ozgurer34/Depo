﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TJK_TV
{
    public partial class Secenekler : Form
    {
        public Secenekler()
        {
            InitializeComponent();
        }

        private void BtnPersonel_Click(object sender, EventArgs e)
        {
            PersonelBilgi frm = new PersonelBilgi();
            frm.Show();
            this.Hide();
        }
    }
}
