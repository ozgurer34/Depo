﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace TJK_TV
{
    class sqlbaglantisi
    {
        public SqlConnection baglanti()
        {
        SqlConnection baglan = new SqlConnection("Data Source=ADMINISTRATOR\\SQLEXPRESS;Initial Catalog=TJK_TV;Integrated Security=True");
        baglan.Open();
        return baglan;
        }
    }
}
