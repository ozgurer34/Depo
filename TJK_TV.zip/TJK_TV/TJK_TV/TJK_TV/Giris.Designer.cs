﻿namespace TJK_TV
{
    partial class Giris
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Giris));
            this.LblGun = new System.Windows.Forms.Label();
            this.LblSaat = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lblAyyıl = new System.Windows.Forms.Label();
            this.LblGunad = new System.Windows.Forms.Label();
            this.LblSaniye = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.LblDakkika = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // LblGun
            // 
            this.LblGun.AutoSize = true;
            this.LblGun.BackColor = System.Drawing.Color.Transparent;
            this.LblGun.Font = new System.Drawing.Font("Encode Sans Condensed", 72F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.LblGun.Location = new System.Drawing.Point(352, 88);
            this.LblGun.Margin = new System.Windows.Forms.Padding(0);
            this.LblGun.Name = "LblGun";
            this.LblGun.Size = new System.Drawing.Size(267, 236);
            this.LblGun.TabIndex = 0;
            this.LblGun.Text = "00";
            // 
            // LblSaat
            // 
            this.LblSaat.AutoSize = true;
            this.LblSaat.BackColor = System.Drawing.Color.Transparent;
            this.LblSaat.Font = new System.Drawing.Font("Encode Sans Condensed", 42F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.LblSaat.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(211)))), ((int)(((byte)(201)))), ((int)(((byte)(34)))));
            this.LblSaat.Location = new System.Drawing.Point(350, 268);
            this.LblSaat.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LblSaat.Name = "LblSaat";
            this.LblSaat.Size = new System.Drawing.Size(153, 138);
            this.LblSaat.TabIndex = 1;
            this.LblSaat.Text = "SA";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(655, 560);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(333, 37);
            this.dateTimePicker1.TabIndex = 2;
            this.dateTimePicker1.Value = new System.DateTime(2020, 2, 18, 20, 29, 6, 0);
            this.dateTimePicker1.Visible = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(954, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(34, 33);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // lblAyyıl
            // 
            this.lblAyyıl.AutoSize = true;
            this.lblAyyıl.BackColor = System.Drawing.Color.Transparent;
            this.lblAyyıl.Font = new System.Drawing.Font("Encode Sans Condensed", 22F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblAyyıl.Location = new System.Drawing.Point(479, 128);
            this.lblAyyıl.Margin = new System.Windows.Forms.Padding(0);
            this.lblAyyıl.Name = "lblAyyıl";
            this.lblAyyıl.Size = new System.Drawing.Size(127, 72);
            this.lblAyyıl.TabIndex = 4;
            this.lblAyyıl.Text = "ay yıl";
            // 
            // LblGunad
            // 
            this.LblGunad.AutoSize = true;
            this.LblGunad.BackColor = System.Drawing.Color.Transparent;
            this.LblGunad.Font = new System.Drawing.Font("Encode Sans Condensed", 22F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.LblGunad.Location = new System.Drawing.Point(479, 181);
            this.LblGunad.Margin = new System.Windows.Forms.Padding(0);
            this.LblGunad.Name = "LblGunad";
            this.LblGunad.Size = new System.Drawing.Size(103, 72);
            this.LblGunad.TabIndex = 5;
            this.LblGunad.Text = "Gun";
            // 
            // LblSaniye
            // 
            this.LblSaniye.AutoSize = true;
            this.LblSaniye.BackColor = System.Drawing.Color.Transparent;
            this.LblSaniye.Font = new System.Drawing.Font("Encode Sans Condensed", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.LblSaniye.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(211)))), ((int)(((byte)(201)))), ((int)(((byte)(34)))));
            this.LblSaniye.Location = new System.Drawing.Point(5, 571);
            this.LblSaniye.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LblSaniye.Name = "LblSaniye";
            this.LblSaniye.Size = new System.Drawing.Size(56, 26);
            this.LblSaniye.TabIndex = 6;
            this.LblSaniye.Text = "Saniye";
            this.LblSaniye.Visible = false;
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // LblDakkika
            // 
            this.LblDakkika.AutoSize = true;
            this.LblDakkika.BackColor = System.Drawing.Color.Transparent;
            this.LblDakkika.Font = new System.Drawing.Font("Encode Sans Condensed", 42F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(150)));
            this.LblDakkika.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(211)))), ((int)(((byte)(201)))), ((int)(((byte)(34)))));
            this.LblDakkika.Location = new System.Drawing.Point(461, 268);
            this.LblDakkika.Margin = new System.Windows.Forms.Padding(0);
            this.LblDakkika.Name = "LblDakkika";
            this.LblDakkika.Size = new System.Drawing.Size(162, 138);
            this.LblDakkika.TabIndex = 7;
            this.LblDakkika.Text = "DK";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(211)))), ((int)(((byte)(201)))), ((int)(((byte)(34)))));
            this.panel1.Location = new System.Drawing.Point(10, 394);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(0, 5);
            this.panel1.TabIndex = 8;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(211)))), ((int)(((byte)(201)))), ((int)(((byte)(34)))));
            this.button1.Enabled = false;
            this.button1.ForeColor = System.Drawing.Color.Transparent;
            this.button1.Location = new System.Drawing.Point(30, 500);
            this.button1.Margin = new System.Windows.Forms.Padding(0);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(0, 5);
            this.button1.TabIndex = 9;
            this.button1.TabStop = false;
            this.button1.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.button1.UseMnemonic = false;
            this.button1.UseVisualStyleBackColor = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Encode Sans Condensed", 42F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(211)))), ((int)(((byte)(201)))), ((int)(((byte)(34)))));
            this.label1.Location = new System.Drawing.Point(425, 268);
            this.label1.Margin = new System.Windows.Forms.Padding(0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(79, 138);
            this.label1.TabIndex = 10;
            this.label1.Text = ":";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(30, 32);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(78, 100);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 11;
            this.pictureBox2.TabStop = false;
            // 
            // Giris
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 39F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(49)))), ((int)(((byte)(47)))));
            this.ClientSize = new System.Drawing.Size(1000, 600);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.LblDakkika);
            this.Controls.Add(this.LblSaniye);
            this.Controls.Add(this.LblGunad);
            this.Controls.Add(this.lblAyyıl);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.LblSaat);
            this.Controls.Add(this.LblGun);
            this.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.Font = new System.Drawing.Font("Encode Sans Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.ForeColor = System.Drawing.Color.White;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Giris";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LblGun;
        private System.Windows.Forms.Label LblSaat;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lblAyyıl;
        private System.Windows.Forms.Label LblGunad;
        private System.Windows.Forms.Label LblSaniye;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label LblDakkika;
        private System.Windows.Forms.Panel panel1;
        internal System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}

